const $ = s => document.querySelector(s);
const TRANS = { PENDIENTE: ['EN_PROCESO', 'CANCELADA'], EN_PROCESO: ['RESUELTA', 'CANCELADA'], RESUELTA: [], CANCELADA: [] };
const ESTADOS = Object.keys(TRANS);
let lista = [], total = {}, tToast;

// Crea elementos; los textos se insertan con append() (texto, nunca HTML)
function h(tag, attrs = {}, ...hijos) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  e.append(...hijos);
  return e;
}

async function api(url, opciones = {}) {
  const r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opciones });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.mensaje || 'Ocurrió un error inesperado.');
  return j;
}

function aviso(msg, tipo = 'ok') {
  const t = $('#toast');
  t.textContent = msg; t.className = `ver ${tipo}`;
  clearTimeout(tToast); tToast = setTimeout(() => t.className = '', 3500);
}

const fecha = f => new Date(f).toLocaleString('es-BO', { dateStyle: 'short', timeStyle: 'short' });
const chip = (clase, txt) => h('span', { class: `chip ${clase}` }, txt.replace('_', ' '));

async function cargar() {
  const p = new URLSearchParams();
  for (const [id, k] of [['#f-q', 'q'], ['#f-prioridad', 'prioridad'], ['#f-estado', 'estado']]) {
    if ($(id).value.trim()) p.set(k, $(id).value.trim());
  }
  try {
    lista = (await api(`/api/solicitudes?${p}`)).datos;
    pintar();
  } catch (e) { aviso(e.message, 'error'); } // el listado anterior se conserva
}

async function cargarResumen() {
  try {
    const todas = (await api('/api/solicitudes')).datos;
    total = Object.fromEntries(ESTADOS.map(e => [e, todas.filter(s => s.estado === e).length]));
    const box = $('#resumen'); box.replaceChildren();
    for (const e of ESTADOS) {
      box.append(h('button', { type: 'button', class: $('#f-estado').value === e ? 'activo' : '', onclick: () => {
        $('#f-estado').value = $('#f-estado').value === e ? '' : e; cargar(); cargarResumen();
      } }, h('b', {}, String(total[e])), h('span', {}, e.replace('_', ' '))));
    }
  } catch (e) { /* el resumen es opcional */ }
}

function pintar() {
  const tb = $('#tbody'); tb.replaceChildren();
  if (!lista.length) {
    tb.append(h('tr', {}, h('td', { colspan: 7, class: 'vacio' }, 'No hay solicitudes que coincidan. Registra una nueva o cambia los filtros.')));
    return;
  }
  for (const s of lista) {
    tb.append(h('tr', {},
      h('td', { class: 'cod' }, s.codigo_solicitud),
      h('td', {}, s.equipo?.nombre || '—'),
      h('td', {}, s.solicitante),
      h('td', {}, chip(`p-${s.prioridad}`, s.prioridad)),
      h('td', {}, chip(`e-${s.estado}`, s.estado)),
      h('td', {}, fecha(s.fecha_registro)),
      h('td', { class: 'acciones' },
        h('button', { class: 'btn', onclick: () => verDetalle(s.id) }, 'Ver'),
        h('button', { class: 'btn', onclick: () => editar(s) }, 'Editar'),
        h('button', { class: 'btn', onclick: () => cambiarEstado(s) }, 'Estado'),
        h('button', { class: 'btn peligro', onclick: () => eliminar(s) }, 'Eliminar'))));
  }
}

// ---------- Diálogo ----------
const dlg = $('#dlg');
function abrir(titulo, ...contenido) { $('#dlg-body').replaceChildren(h('h3', {}, titulo), ...contenido); dlg.showModal(); }
const cerrar = () => dlg.close();
const btnCerrar = txt => h('button', { type: 'button', class: 'btn', onclick: cerrar }, txt);

async function verDetalle(id) {
  try {
    const s = (await api(`/api/solicitudes/${id}`)).datos;
    const filas = [['Código', s.codigo_solicitud], ['Equipo', `${s.equipo.codigo} · ${s.equipo.nombre}`], ['Ubicación', s.equipo.ubicacion],
      ['Solicitante', s.solicitante], ['Descripción', s.descripcion], ['Prioridad', s.prioridad], ['Estado', s.estado],
      ['Registrada', fecha(s.fecha_registro)], ['Actualizada', fecha(s.fecha_actualizacion)]];
    abrir('Detalle de la solicitud', h('dl', {}, ...filas.flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])),
      h('div', { class: 'botones' }, btnCerrar('Cerrar')));
  } catch (e) { aviso(e.message, 'error'); }
}

function editar(s) {
  const sol = h('input', { maxlength: 100, value: s.solicitante });
  const des = h('textarea', { rows: 4 }, s.descripcion);
  const pri = h('select', {}, ...['BAJA', 'MEDIA', 'ALTA'].map(p => h('option', p === s.prioridad ? { selected: '' } : {}, p)));
  const form = h('form', { novalidate: '', onsubmit: async ev => {
    ev.preventDefault();
    if (sol.value.trim().length < 3) return aviso('El solicitante debe tener al menos 3 caracteres.', 'error');
    if (des.value.trim().length < 10) return aviso('La descripción debe tener al menos 10 caracteres.', 'error');
    try {
      const r = await api(`/api/solicitudes/${s.id}`, { method: 'PUT', body: JSON.stringify({ solicitante: sol.value, descripcion: des.value, prioridad: pri.value }) });
      cerrar(); aviso(r.mensaje); cargar();
    } catch (e) { aviso(e.message, 'error'); }
  } },
    h('label', {}, 'Solicitante', sol), h('label', {}, 'Descripción', des), h('label', {}, 'Prioridad', pri),
    h('div', { class: 'botones' }, btnCerrar('Cancelar'), h('button', { class: 'btn primary', style: 'width:auto', type: 'submit' }, 'Guardar cambios')));
  abrir(`Editar ${s.codigo_solicitud}`, form);
}

function cambiarEstado(s) {
  const sel = h('select', {}, ...ESTADOS.map(e => h('option', e === s.estado ? { selected: '' } : {}, e)));
  const av = h('p', { class: 'aviso' });
  sel.addEventListener('change', () => {
    const valida = TRANS[s.estado].includes(sel.value);
    av.textContent = valida || sel.value === s.estado ? '' : `Transición no permitida: de ${s.estado} a ${sel.value}.`;
  });
  const form = h('form', { onsubmit: async ev => {
    ev.preventDefault();
    try {
      const r = await api(`/api/solicitudes/${s.id}/estado`, { method: 'PATCH', body: JSON.stringify({ estado: sel.value }) });
      cerrar(); aviso(r.mensaje); cargar(); cargarResumen();
    } catch (e) { aviso(e.message, 'error'); }
  } }, h('label', {}, `Estado actual: ${s.estado}. Nuevo estado`, sel), av,
    h('div', { class: 'botones' }, btnCerrar('Cancelar'), h('button', { class: 'btn primary', style: 'width:auto', type: 'submit' }, 'Cambiar estado')));
  abrir(`Cambiar estado de ${s.codigo_solicitud}`, form);
}

async function eliminar(s) {
  if (!confirm(`¿Eliminar la solicitud ${s.codigo_solicitud}? Dejará de mostrarse en el listado.`)) return;
  try { const r = await api(`/api/solicitudes/${s.id}`, { method: 'DELETE' }); aviso(r.mensaje); cargar(); cargarResumen(); }
  catch (e) { aviso(e.message, 'error'); }
}

// ---------- Formulario nueva solicitud ----------
$('#form-nueva').addEventListener('submit', async ev => {
  ev.preventDefault();
  const d = { equipo_id: $('#n-equipo').value, solicitante: $('#n-solicitante').value, descripcion: $('#n-descripcion').value, prioridad: $('#n-prioridad').value };
  if (!d.equipo_id) return aviso('Selecciona un equipo.', 'error');
  if (d.solicitante.trim().length < 3) return aviso('El solicitante debe tener al menos 3 caracteres.', 'error');
  if (d.descripcion.trim().length < 10) return aviso('La descripción debe tener al menos 10 caracteres.', 'error');
  try {
    const r = await api('/api/solicitudes', { method: 'POST', body: JSON.stringify(d) });
    ev.target.reset(); aviso(`${r.mensaje} Código: ${r.datos.codigo_solicitud}`); cargar(); cargarResumen();
  } catch (e) { aviso(e.message, 'error'); }
});

let debounce;
$('#f-q').addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(cargar, 250); });
for (const id of ['#f-prioridad', '#f-estado']) $(id).addEventListener('change', () => { cargar(); cargarResumen(); });

(async function iniciar() {
  try {
    const eq = (await api('/api/equipos')).datos.filter(e => e.estado === 'OPERATIVO');
    $('#n-equipo').replaceChildren(h('option', { value: '' }, 'Selecciona un equipo…'),
      ...eq.map(e => h('option', { value: e.id }, `${e.codigo} · ${e.nombre} (${e.ubicacion})`)));
  } catch (e) { aviso(e.message, 'error'); }
  cargar(); cargarResumen();
})();
