class AppError extends Error {
  constructor(status, mensaje) { super(mensaje); this.status = status; }
}

function errorHandler(err, req, res, next) {
  if (err instanceof AppError) return res.status(err.status).json({ ok: false, mensaje: err.message });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ ok: false, mensaje: 'El JSON enviado no es válido.' });
  console.error(err); // la traza solo queda en el log del servidor
  res.status(500).json({ ok: false, mensaje: 'Error interno del servidor.' });
}

module.exports = { AppError, errorHandler };
