const { crearServicio } = require('../services/solicitud.service');
const servicio = crearServicio(require('../models/solicitud.model'), require('../models/equipo.model'));

const ok = (res, status, datos, mensaje) => res.status(status).json({ ok: true, datos, mensaje });

module.exports = {
  listar: async (req, res) => ok(res, 200, await servicio.listar(req.query)),
  obtener: async (req, res) => ok(res, 200, await servicio.obtener(req.params.id)),
  crear: async (req, res) => ok(res, 201, await servicio.crear(req.body), 'Solicitud registrada correctamente.'),
  actualizar: async (req, res) => ok(res, 200, await servicio.actualizar(req.params.id, req.body), 'Solicitud actualizada correctamente.'),
  cambiarEstado: async (req, res) => ok(res, 200, await servicio.cambiarEstado(req.params.id, (req.body || {}).estado), 'Estado actualizado correctamente.'),
  eliminar: async (req, res) => ok(res, 200, await servicio.eliminar(req.params.id), 'Solicitud eliminada correctamente.')
};
