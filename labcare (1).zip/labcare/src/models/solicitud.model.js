const db = require('../config/supabase');
const SEL = '*, equipo:equipo_id(id, codigo, nombre, ubicacion)';

async function listar({ prioridad, estado } = {}) {
  let q = db.from('solicitud').select(SEL).eq('activo', true).order('fecha_registro', { ascending: false });
  if (prioridad) q = q.eq('prioridad', prioridad);
  if (estado) q = q.eq('estado', estado);
  const { data, error } = await q;
  if (error) throw error;
  return data;
}
async function obtener(id) {
  const { data, error } = await db.from('solicitud').select(SEL).eq('id', id).eq('activo', true).maybeSingle();
  if (error) throw error;
  return data;
}
async function contarPorPrefijo(prefijo) {
  const { count, error } = await db.from('solicitud').select('id', { count: 'exact', head: true }).like('codigo_solicitud', `${prefijo}%`);
  if (error) throw error;
  return count || 0;
}
async function crear(datos) {
  const { data, error } = await db.from('solicitud').insert(datos).select(SEL).single();
  if (error) throw error;
  return data;
}
async function actualizar(id, cambios) {
  const { data, error } = await db.from('solicitud').update(cambios).eq('id', id).select(SEL).single();
  if (error) throw error;
  return data;
}
module.exports = { listar, obtener, contarPorPrefijo, crear, actualizar };
