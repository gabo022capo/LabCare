const db = require('../config/supabase');

async function listar() {
  const { data, error } = await db.from('equipo').select('*').order('codigo');
  if (error) throw error;
  return data;
}
async function obtener(id) {
  const { data, error } = await db.from('equipo').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}
module.exports = { listar, obtener };
