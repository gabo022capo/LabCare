const { AppError } = require('../middlewares/errorHandler');

const PRIORIDADES = ['BAJA', 'MEDIA', 'ALTA'];
const TRANSICIONES = {
  PENDIENTE: ['EN_PROCESO', 'CANCELADA'],
  EN_PROCESO: ['RESUELTA', 'CANCELADA'],
  RESUELTA: [],
  CANCELADA: []
};
const ESTADOS = Object.keys(TRANSICIONES);

function texto(v) { return typeof v === 'string' ? v.trim() : ''; }

function validarId(id) {
  if (!/^\d+$/.test(String(id))) throw new AppError(400, 'El id debe ser un número entero positivo.');
  return Number(id);
}

function validarDescriptivos(d = {}) {
  const solicitante = texto(d.solicitante), descripcion = texto(d.descripcion);
  if (solicitante.length < 3) throw new AppError(400, 'El solicitante es obligatorio (mínimo 3 caracteres).');
  if (descripcion.length < 10) throw new AppError(400, 'La descripción es obligatoria (mínimo 10 caracteres).');
  if (!PRIORIDADES.includes(d.prioridad)) throw new AppError(400, 'La prioridad debe ser BAJA, MEDIA o ALTA.');
  return { solicitante, descripcion, prioridad: d.prioridad };
}

function crearServicio(repo, equipos) {
  async function obtenerExistente(id) {
    const s = await repo.obtener(validarId(id));
    if (!s) throw new AppError(404, 'La solicitud no existe.');
    return s;
  }

  async function generarCodigo() {
    const prefijo = `SOL-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-`;
    const n = await repo.contarPorPrefijo(prefijo);
    return prefijo + String(n + 1).padStart(3, '0');
  }

  return {
    async listar({ q, prioridad, estado } = {}) {
      if (prioridad && !PRIORIDADES.includes(prioridad)) throw new AppError(400, 'Filtro de prioridad inválido.');
      if (estado && !ESTADOS.includes(estado)) throw new AppError(400, 'Filtro de estado inválido.');
      let lista = await repo.listar({ prioridad, estado });
      const t = texto(q).toLowerCase();
      if (t) {
        lista = lista.filter(s => [s.codigo_solicitud, s.solicitante, s.equipo?.nombre]
          .some(v => (v || '').toLowerCase().includes(t)));
      }
      return lista;
    },

    obtener: obtenerExistente,

    async crear(body = {}) {
      const datos = validarDescriptivos(body);
      const equipoId = Number(body.equipo_id);
      if (!Number.isInteger(equipoId) || equipoId <= 0) throw new AppError(400, 'Debe seleccionar un equipo.');
      const equipo = await equipos.obtener(equipoId);
      if (!equipo) throw new AppError(400, 'El equipo seleccionado no existe.');
      if (equipo.estado !== 'OPERATIVO') throw new AppError(400, 'El equipo no está disponible (debe estar OPERATIVO).');

      for (let intento = 0; intento < 5; intento++) {
        try {
          return await repo.crear({ ...datos, equipo_id: equipoId, estado: 'PENDIENTE', codigo_solicitud: await generarCodigo() });
        } catch (e) {
          if (e.code !== '23505') throw e; // solo reintenta ante código duplicado
        }
      }
      throw new AppError(409, 'No se pudo generar un código único. Intente nuevamente.');
    },

    async actualizar(id, body) {
      const s = await obtenerExistente(id);
      return repo.actualizar(s.id, validarDescriptivos(body)); // id, código, estado y fecha no se tocan
    },

    async cambiarEstado(id, nuevo) {
      const actual = await obtenerExistente(id);
      if (!ESTADOS.includes(nuevo)) throw new AppError(400, 'Estado inválido.');
      if (!TRANSICIONES[actual.estado].includes(nuevo)) {
        throw new AppError(409, `Transición no permitida: de ${actual.estado} a ${nuevo}.`);
      }
      return repo.actualizar(actual.id, { estado: nuevo });
    },

    async eliminar(id) {
      const s = await obtenerExistente(id);
      return repo.actualizar(s.id, { activo: false });
    }
  };
}

module.exports = { crearServicio, TRANSICIONES };
