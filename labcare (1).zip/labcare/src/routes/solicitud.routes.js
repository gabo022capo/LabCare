const router = require('express').Router();
const c = require('../controllers/solicitud.controller');
const wrap = fn => (req, res, next) => fn(req, res).catch(next);

router.get('/', wrap(c.listar));
router.get('/:id', wrap(c.obtener));
router.post('/', wrap(c.crear));
router.put('/:id', wrap(c.actualizar));
router.patch('/:id/estado', wrap(c.cambiarEstado));
router.delete('/:id', wrap(c.eliminar));
module.exports = router;
