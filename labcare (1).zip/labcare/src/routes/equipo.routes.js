const router = require('express').Router();
const equipos = require('../models/equipo.model');
router.get('/', (req, res, next) =>
  equipos.listar().then(datos => res.json({ ok: true, datos })).catch(next));
module.exports = router;
