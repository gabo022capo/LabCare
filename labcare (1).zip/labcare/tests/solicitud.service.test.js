const test = require('node:test');
const assert = require('node:assert/strict');
const { crearServicio } = require('../src/services/solicitud.service');

function crearEntorno() {
  const filas = [];
  const equipo = { id: 1, codigo: 'EQ-001', nombre: 'Computadora', estado: 'OPERATIVO' };
  const repo = {
    listar: async f => filas.filter(s => s.activo && (!f.estado || s.estado === f.estado) && (!f.prioridad || s.prioridad === f.prioridad)),
    obtener: async id => filas.find(s => s.id === id && s.activo) || null,
    contarPorPrefijo: async p => filas.filter(s => s.codigo_solicitud.startsWith(p)).length,
    crear: async d => { const s = { id: filas.length + 1, activo: true, equipo, ...d }; filas.push(s); return s; },
    actualizar: async (id, c) => Object.assign(filas.find(s => s.id === id), c)
  };
  const equipos = { obtener: async id => (id === 1 ? equipo : null) };
  return { filas, svc: crearServicio(repo, equipos) };
}
const valida = { equipo_id: 1, solicitante: 'Ana Pérez', descripcion: 'La pantalla no enciende', prioridad: 'ALTA' };
const rechaza = (p, status) => assert.rejects(p, e => e.status === status);

test('CP-01 registra solicitud PENDIENTE con código único', async () => {
  const { svc } = crearEntorno();
  const a = await svc.crear(valida), b = await svc.crear(valida);
  assert.equal(a.estado, 'PENDIENTE');
  assert.match(a.codigo_solicitud, /^SOL-\d{8}-001$/);
  assert.notEqual(a.codigo_solicitud, b.codigo_solicitud);
});
test('CP-02 rechaza solicitante corto', async () => {
  const { svc, filas } = crearEntorno();
  await rechaza(svc.crear({ ...valida, solicitante: ' a ' }), 400);
  assert.equal(filas.length, 0);
});
test('CP-03 rechaza descripción corta', async () => {
  const { svc } = crearEntorno();
  await rechaza(svc.crear({ ...valida, descripcion: 'corta' }), 400);
});
test('CP-04 rechaza prioridad inválida', async () => {
  const { svc } = crearEntorno();
  await rechaza(svc.crear({ ...valida, prioridad: 'URGENTE' }), 400);
});
test('CP-05 rechaza equipo inexistente', async () => {
  const { svc, filas } = crearEntorno();
  await rechaza(svc.crear({ ...valida, equipo_id: 99 }), 400);
  assert.equal(filas.length, 0);
});
test('CP-06 editar conserva código y estado', async () => {
  const { svc } = crearEntorno();
  const s = await svc.crear(valida);
  const e = await svc.actualizar(s.id, { ...valida, solicitante: 'Luis Gómez' });
  assert.equal(e.solicitante, 'Luis Gómez');
  assert.equal(e.codigo_solicitud, s.codigo_solicitud);
  assert.equal(e.estado, 'PENDIENTE');
});
test('CP-07/08 transiciones: PENDIENTE→EN_PROCESO ok, RESUELTA→PENDIENTE 409', async () => {
  const { svc } = crearEntorno();
  const s = await svc.crear(valida);
  assert.equal((await svc.cambiarEstado(s.id, 'EN_PROCESO')).estado, 'EN_PROCESO');
  await svc.cambiarEstado(s.id, 'RESUELTA');
  await rechaza(svc.cambiarEstado(s.id, 'PENDIENTE'), 409);
  assert.equal((await svc.obtener(s.id)).estado, 'RESUELTA');
});
test('CP-09 eliminación lógica', async () => {
  const { svc, filas } = crearEntorno();
  const s = await svc.crear(valida);
  await svc.eliminar(s.id);
  assert.equal((await svc.listar()).length, 0);
  assert.equal(filas.length, 1);
  assert.equal(filas[0].activo, false);
});
test('CP-10 búsqueda y filtros', async () => {
  const { svc } = crearEntorno();
  await svc.crear(valida);
  await svc.crear({ ...valida, solicitante: 'Zoe Rivas', prioridad: 'BAJA' });
  assert.equal((await svc.listar({ q: 'ZOE' })).length, 1);
  assert.equal((await svc.listar({ prioridad: 'ALTA' })).length, 1);
  await rechaza(svc.listar({ estado: 'XX' }), 400);
});
test('CP-11 id inexistente 404, mal formado 400', async () => {
  const { svc } = crearEntorno();
  await rechaza(svc.obtener(999), 404);
  await rechaza(svc.obtener('abc'), 400);
});
