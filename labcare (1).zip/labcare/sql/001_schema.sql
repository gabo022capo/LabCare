-- LabCare · Esquema + datos de ejemplo · Ejecutar en Supabase > SQL Editor

-- ============ TABLAS ============
create table if not exists public.equipo (
  id bigint generated always as identity primary key,
  codigo varchar(20) not null unique,
  nombre varchar(100) not null,
  ubicacion varchar(100) not null,
  estado varchar(20) not null default 'OPERATIVO'
    check (estado in ('OPERATIVO','EN_MANTENIMIENTO','BAJA'))
);

create table if not exists public.solicitud (
  id bigint generated always as identity primary key,
  codigo_solicitud varchar(30) not null unique,
  equipo_id bigint not null references public.equipo(id),
  solicitante varchar(100) not null check (char_length(btrim(solicitante)) >= 3),
  descripcion text not null check (char_length(btrim(descripcion)) >= 10),
  prioridad varchar(10) not null check (prioridad in ('BAJA','MEDIA','ALTA')),
  estado varchar(15) not null default 'PENDIENTE'
    check (estado in ('PENDIENTE','EN_PROCESO','RESUELTA','CANCELADA')),
  fecha_registro timestamptz not null default now(),
  fecha_actualizacion timestamptz not null default now(),
  activo boolean not null default true
);

-- ============ ÍNDICES ============
create index if not exists idx_solicitud_equipo on public.solicitud(equipo_id);
create index if not exists idx_solicitud_estado on public.solicitud(estado) where activo;
create index if not exists idx_solicitud_prioridad on public.solicitud(prioridad) where activo;

-- ============ TRIGGER: fecha_actualizacion ============
create or replace function public.set_fecha_actualizacion()
returns trigger language plpgsql as $$
begin
  new.fecha_actualizacion = now();
  return new;
end $$;

drop trigger if exists trg_solicitud_actualizacion on public.solicitud;
create trigger trg_solicitud_actualizacion
  before update on public.solicitud
  for each row execute function public.set_fecha_actualizacion();

-- ============ SEGURIDAD (RLS) ============
-- Sin políticas: la clave pública (anon) no puede leer ni escribir.
-- El backend usa service_role, que ignora RLS.
alter table public.equipo enable row level security;
alter table public.solicitud enable row level security;

-- ============ DATOS: EQUIPOS ============
insert into public.equipo (codigo, nombre, ubicacion, estado) values
  ('EQ-001', 'Computadora de escritorio', 'Laboratorio 1', 'OPERATIVO'),
  ('EQ-002', 'Proyector multimedia', 'Aula 204', 'OPERATIVO'),
  ('EQ-003', 'Router de laboratorio', 'Laboratorio de Redes', 'OPERATIVO'),
  ('EQ-004', 'Impresora de oficina', 'Secretaría', 'OPERATIVO')
on conflict (codigo) do nothing;

-- ============ DATOS: SOLICITUDES DE EJEMPLO ============
insert into public.solicitud
  (codigo_solicitud, equipo_id, solicitante, descripcion, prioridad, estado, fecha_registro, activo)
select v.codigo, e.id, v.solicitante, v.descripcion, v.prioridad, v.estado, now() - v.hace, v.activo
from (values
  ('SOL-20261116-001', 'EQ-001', 'María Fernández',  'La computadora no enciende después del corte de energía de ayer.', 'ALTA',  'PENDIENTE',  interval '7 days',  true),
  ('SOL-20261117-001', 'EQ-002', 'Carlos Quispe',    'El proyector muestra la imagen con una mancha verde en el centro.', 'MEDIA', 'EN_PROCESO', interval '6 days',  true),
  ('SOL-20261118-001', 'EQ-003', 'Lucía Rojas',      'El router pierde conexión cada 20 minutos en la práctica de redes.', 'ALTA',  'EN_PROCESO', interval '5 days',  true),
  ('SOL-20261118-002', 'EQ-004', 'Jorge Mamani',     'La impresora deja rayas negras en todas las hojas que imprime.', 'BAJA',  'RESUELTA',   interval '5 days',  true),
  ('SOL-20261119-001', 'EQ-001', 'Ana Villarroel',   'El teclado tiene varias teclas que no responden al presionar.', 'BAJA',  'CANCELADA',  interval '4 days',  true),
  ('SOL-20261120-001', 'EQ-002', 'Pedro Condori',    'El control remoto del proyector no responde, posible pila agotada.', 'BAJA',  'PENDIENTE',  interval '3 days',  true),
  ('SOL-20261121-001', 'EQ-004', 'Rosa Choque',      'Atasco de papel frecuente en la bandeja principal de la impresora.', 'MEDIA', 'PENDIENTE',  interval '2 days',  true),
  ('SOL-20261122-001', 'EQ-003', 'Luis Herrera',     'Solicitud duplicada registrada por error (eliminada lógicamente).', 'MEDIA', 'PENDIENTE',  interval '1 day',   false)
) as v(codigo, equipo_codigo, solicitante, descripcion, prioridad, estado, hace, activo)
join public.equipo e on e.codigo = v.equipo_codigo
on conflict (codigo_solicitud) do nothing;

-- Verificación
-- select * from public.equipo;
-- select codigo_solicitud, estado, prioridad, activo from public.solicitud order by id;
